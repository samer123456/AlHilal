<?php $this->load->view('admin/_head'); ?>
<?php $this->load->view('admin/_header'); ?>
<?php $this->load->view('admin/_sidebar'); ?>
<?php $this->load->view('admin/unreadMessages'); ?>
<?php $this->load->view('admin/dashboard'); ?>
<?php $this->load->view('admin/_footer'); ?>
