<!doctype html>
<html class="fixed">
<head>
	<meta charset="UTF-8">
	<title>Admin Panel | IB Trading Company</title>
	<meta name="keywords" content="HTML5 Admin Template"/>
	<meta name="description" content="JSOFT Admin - Responsive HTML5 Template">
	<meta name="author" content="JSOFT.net">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" href="<?php echo base_url(); ?>uploads/favicon.png">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light"
		  rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/assets/vendor/bootstrap/css/bootstrap.css"/>
	<link rel="stylesheet"
		  href="<?php echo base_url(); ?>assets/admin/assets/vendor/font-awesome/css/font-awesome.css"/>
	<link rel="stylesheet"
		  href="<?php echo base_url(); ?>assets/admin/assets/vendor/magnific-popup/magnific-popup.css"/>
	<link rel="stylesheet"
		  href="<?php echo base_url(); ?>assets/admin/assets/vendor/bootstrap-datepicker/css/datepicker3.css"/>
	<link rel="stylesheet"
		  href="<?php echo base_url(); ?>assets/admin/assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css"/>
	<link rel="stylesheet"
		  href="<?php echo base_url(); ?>assets/admin/assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css"/>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/assets/vendor/morris/morris.css"/>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/assets/stylesheets/theme.css"/>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/assets/stylesheets/skins/default.css"/>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/assets/stylesheets/theme-custom.css">
	<script src="<?php echo base_url(); ?>assets/admin/assets/vendor/modernizr/modernizr.js"></script>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/assets/vendor/pnotify/pnotify.custom.css"/>
	<script src="https://cdn.tiny.cloud/1/vr5rqs9s2fj0ci2bbxsndsyvkolg9cvd228wexsr46h5lnor/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
	<script>
		tinymce.init({
			selector: '#mytextarea'
		});
	</script>
</head>


