<?php $this->load->view('_head'); ?>
<?php $this->load->view('_header'); ?>
<div class="parallax inverse-text"
	 data-parallax-img="<?php echo base_url(); ?>uploads/parallax3.jpg"
	 data-parallax-img-width="1920" data-parallax-img-height="1223">
	<div class="container inner pt-120 pb-120 text-center">
		<h1 class="section-title"><?php echo $home[0]->tab_3; ?></h1>
		<p class="lead text-center mb-0">We are here to serve you
		<p>
	</div>
</div>
<?php
if($home[0]->tab_7=="Ar"){
	$cls = "dir='rtl'";
}else{
	$cls ="";
}
?>
<div class="wrapper light-wrapper">
	<div class="container inner">
		<div class="row">
			<?php
			$counter = 0;
			foreach ($service as $rs) {
				$counter++;
				if ($counter % 2 !== 0) {
					$cls_img = "col-sm-push-6";
					$cls_txt = "col-sm-pull-6";
				} else {
					$cls_img = "";
					$cls_txt = "";
				}
				?>
				<div class="space20 visible-xs clearfix"></div>
				<div class="col-md-10 col-md-offset-1">
					<div class="row flex-middle">
						<div class="col-sm-6 <?php echo $cls_img; ?>">
							<div class="icon-img icon-svg icon-l"><img
										src="<?php echo base_url(); ?>uploads/<?php echo $rs->icon_name; ?>"
										alt=""/></div>
						</div>
						<div class="space20 visible-xs clearfix"></div>
						<div class="col-sm-6 <?php echo $cls_txt; ?>" <?php echo $cls; ?>>
							<h2><?php echo $rs->title; ?></h2>
							<p class="lead2 mb-0"><?php echo $rs->info; ?></p><br>
						</div>
					</div>
					<div class="space70"></div>
				</div>
			<?php } ?>
		</div>
	</div>
</div>
</div>
<div class="wrapper light-wrapper">
	<div class="container inner">
		<h2 class="section-title text-center"><?php echo $s_slider[0]->section_title; ?></h2>
		<p class="lead text-center"><?php echo $s_slider[0]->section_info; ?></p>
		<div class="space30"></div>
		<div class="tiles">
			<div class="items row">
				<?php foreach ($s_slider as $rs) { ?>
					<div class="item col-xs-6 col-sm-6 col-md-4">
						<figure class="overlay overlay6 color"><img
									src="<?php echo base_url(); ?>uploads/<?php echo $rs->image_name; ?>"
									alt=""/>
							<figcaption>
								<h4 class="mb-5"><?php echo $rs->image_title; ?></h4>
							</figcaption>
						</figure>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
</div>
<?php $this->load->view('_footer'); ?>
<?php $this->load->view('_footerscript'); ?>
