<script type="text/javascript" src="<?php echo base_url(); ?>assets/style/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/style/js/bootstrap.min.js"></script>
<script type="text/javascript"
		src="<?php echo base_url(); ?>assets/style/revolution/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript"
		src="<?php echo base_url(); ?>assets/style/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript"
		src="<?php echo base_url(); ?>assets/style/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript"
		src="<?php echo base_url(); ?>assets/style/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript"
		src="<?php echo base_url(); ?>assets/style/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript"
		src="<?php echo base_url(); ?>assets/style/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script type="text/javascript"
		src="<?php echo base_url(); ?>assets/style/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script type="text/javascript"
		src="<?php echo base_url(); ?>assets/style/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/style/js/plugins.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/style/js/scripts.js"></script>
</body>
</html>
