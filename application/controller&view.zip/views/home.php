<?php $this->load->view('_head'); ?>
<?php $this->load->view('_header'); ?>
<?php $this->load->view('slider'); ?>
<?php $this->load->view('why_us'); ?>
<?php $this->load->view('products'); ?>
<?php $this->load->view('_footer'); ?>
<?php $this->load->view('_footerscript'); ?>
