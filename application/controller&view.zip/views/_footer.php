<footer class="gray-wrapper">
	<div class="container inner pt-60 pb-60">
		<div class="row">
			<div class="col-sm-3">
				<div class="widget"><a href="<?php echo base_url(); ?>"> <img src="#"
																						 srcset="<?php echo base_url(); ?>uploads/<?php echo $logo[0]->logo_name; ?> 1x, <?php echo base_url(); ?>uploads/<?php echo $logo[1]->logo_name; ?> 2x"
																						 alt=""/></a>
					<div class="space20"></div>
					<p><?php echo $footer[0]->info; ?></p>
				</div>
			</div>
			<div class="col-sm-3 col-sm-offset-6">
				<div class="widget">
					<h5 class="widget-title"><?php echo $footer[0]->title; ?></h5>
					<ul class="icon-list">
						<li><i class="et-location-pin"></i><?php echo $footer[0]->address; ?></li>
						<li><i class="et-mail"></i> <a href="mailto:first.last@email.com"
													   class="nocolor"><?php echo $footer[0]->email; ?></a>
						</li>
						<li><i class="et-old-phone"></i> <?php echo $footer[0]->phone_1; ?></li>
						<li><i class="et-mobile"></i> <?php echo $footer[0]->phone_2; ?></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<hr class="pt-0 mb-0"/>
	</div>
	<div class="sub-footer">
		<div class="container inner">
			<div class="cell text-left">
				<p>©
					<script>document.write(new Date().getFullYear());</script> <?php echo $footer[0]->copyright; ?> </p>
			</div>
			<div class="cell text-right">
				<ul class="social social-bg social-s">
					<li><a href="<?php echo $footer[0]->twitter; ?>" target="_blank"><i class="et-twitter"></i></a></li>
					<li><a href="<?php echo $footer[0]->facebook; ?>" target="_blank"><i class="et-facebook"></i></a>
					</li>
					<li><a href="<?php echo $footer[0]->instagram; ?>" target="_blank"><i class="et-instagram"></i></a>
					</li>
					<li><a href="<?php echo $footer[0]->linkedin; ?>" target="_blank"><i class="et-linkedin"></i></a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</footer>
